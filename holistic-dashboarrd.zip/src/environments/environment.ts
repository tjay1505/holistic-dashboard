export const environment = {
  production: true,
  landUrl: 'https://landapi.tnhb.in',
  monitoringUrl: 'https://monitoringapi.tnhb.in',
  personnelUrl: 'https://personnelapi.tnhb.in',
  payrollUrl: 'https://payrollapi.tnhb.in',
};
